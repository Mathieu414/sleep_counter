package mathieu.com;

import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.File;
import java.io.FileWriter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import mathieu.com.ui.home.TimePickerFragment;
import mathieu.com.ui.home.TimePickerFragment2;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity<state> extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private File fileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        if(checkPermission()) {
            File file = new File(Environment.getExternalStorageDirectory()+File.separator+"SleepData");
            if (!file.exists()) {
                file.mkdir();
                Toast.makeText(MainActivity.this, "Fichier de sauvegarde créé", Toast.LENGTH_LONG).show();
            }
            try {
                File gpxFile = new File(file, "Data.txt");
                fileName = gpxFile;
            } catch (Exception e) { }
        }
        else {
            requestPermission();
            if(checkPermission()) {
                File file = new File(Environment.getExternalStorageDirectory()+File.separator+"SleepData");
                if (!file.exists()) {
                    file.mkdir();
                    Toast.makeText(MainActivity.this, "Fichier de sauvegarde créé", Toast.LENGTH_LONG).show();
                }
                try {
                    File gpxFile = new File(file, "Data.txt");
                    fileName = gpxFile;
                } catch (Exception e) { }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                }
                break;
        }
    }
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(MainActivity.this, "Write External Storage permission allows us to create files. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    public void showTimePickerDialog(View v) {
        DialogFragment newFragment = new TimePickerFragment(timePickerListener1);
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }

    TimePickerDialog.OnTimeSetListener timePickerListener1 = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            if(checkPermission()) {
                String content = hourOfDay + "\t" + minute + "\t";
                WriteFile(fileName, content);
            }
            DialogFragment newFragment2 = new TimePickerFragment2(timePickerListener2);
            newFragment2.show(getSupportFragmentManager(), "timePicker2");
        }
    };

    TimePickerDialog.OnTimeSetListener timePickerListener2 = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            if(checkPermission()) {
                String content = hourOfDay + "\t" + minute + "\n";
                WriteFile(fileName, content);
            }
        }
    };

    public void WriteFile(File file_path, String content){
        try {
            FileWriter writer = new FileWriter(file_path, true);
            writer.write(content);
            writer.close();
        } catch ( Exception e ) {}
    }

}